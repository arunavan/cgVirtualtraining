package com.cg.spring.dao;

import java.util.List;

import com.cg.spring.model.EmployeeVO;



public interface EmployeeDAO 
{
	public List<EmployeeVO> getAllEmployees();
}