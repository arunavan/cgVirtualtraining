package com.cg.spring.service;

import java.util.List;

import com.cg.spring.model.EmployeeVO;



public interface EmployeeManager 
{
	public List<EmployeeVO> getAllEmployees();
}
