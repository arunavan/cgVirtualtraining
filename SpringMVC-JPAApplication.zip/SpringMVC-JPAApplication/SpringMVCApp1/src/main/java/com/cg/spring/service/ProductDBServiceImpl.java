package com.cg.spring.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.dao.IProductDao;
import com.cg.spring.model.Product;

@Service("productDbService")
public class ProductDBServiceImpl implements IProductService {
	
	@Autowired
	private IProductDao productDbDao;

	@Override
	public List<Product> getAllProducts() {
		
		return productDbDao.getAllProducts();
	}

	@Override
	public Product findProduct(Integer productId) {
		// TODO Auto-generated method stub
		Product product=productDbDao.findProduct(productId);
		return product;
	}

	@Override
	public List<Product> deleteProduct(Integer productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> saveProduct(Product product) {
		// TODO Auto-generated method stub
		return productDbDao.saveProduct(product);
	}

	@Override
	public List<Product> updateProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> saveAll() {
		
		return productDbDao.saveAll();
	}

}
